### Hybrid RAG ( BM25 + Semantic search )


### Execution instructions

pip install -r requirements.txt

cd app

python ingest.py

python -m streamlit run app.py