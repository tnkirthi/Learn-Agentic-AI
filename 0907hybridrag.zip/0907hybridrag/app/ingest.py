### libraries for ingestion logic

from langchain_community.document_loaders import DirectoryLoader, TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma


### ingesting all files from a folder

loader=DirectoryLoader("../data",glob="**/*.md",loader_cls=TextLoader)
docs=loader.load()
chunks=RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200).split_documents(docs)
emb=HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
Chroma.from_documents(chunks,emb,persist_directory="../chroma_db")

print("Indexed",len(chunks), "chunks")

