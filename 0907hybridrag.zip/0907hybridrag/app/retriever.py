from langchain_community.document_loaders import DirectoryLoader, TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma
from langchain_community.retrievers import BM25Retriever ### Best match or exacxt search
from langchain_classic.retrievers import EnsembleRetriever

loader=DirectoryLoader("../data",glob="**/*.md",loader_cls=TextLoader)
docs=loader.load()
chunks=RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200).split_documents(docs)
emb=HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")


### logic for BM25 search
bm25=BM25Retriever.from_documents(chunks)
bm25.k=5

## logic for semantic search

db=Chroma(persist_directory="../chroma_db",embedding_function=emb)
vector=db.as_retriever(search_kwargs={"k":5})


### Hybrid RAG

retriever=EnsembleRetriever(
    retrievers=[bm25,vector],
    weight=[0.4,0.6]
)


