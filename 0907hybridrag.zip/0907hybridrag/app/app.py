import streamlit as st
from retriever import retriever
from llm import get_llm
from langchain_classic.chains import create_retrieval_chain ### RAG pipeline
from langchain_core.prompts import ChatPromptTemplate
from langchain_classic.chains.combine_documents import create_stuff_documents_chain


st.set_page_config(page_title="Enterprise Hybrid RAG")
st.title("Enterprise RAG(Gemini)")

llm=get_llm()

prompt=ChatPromptTemplate.from_template("""
You are an Enterprise AI Assistant.
                                        
Answer ONLY from the supllied context.
If the answer is unavailable, say "I don't know."

Context:
{context}
                                        
Question:
{input}
""")

document_chain=create_stuff_documents_chain(llm, prompt)
rag_chain=create_retrieval_chain(retriever,document_chain)

question=st.text_input("Ask a question")

if st.button("Ask") and question:
    result=rag_chain.invoke({"input":question})

    st.subheader("Answer")
    st.write(result["answer"])