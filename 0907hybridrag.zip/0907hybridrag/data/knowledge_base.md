### Enterprise Knowledge base

Azure Kubernetes Services(AKS) supports Cluster Autoscaler and Horizontal Pod Autoscaler
Terraform uses azurerm provider to provision Azure resources
langchain EnsembleRetriever combines BM25 and semantic serch
AI is a helpfull human assistant