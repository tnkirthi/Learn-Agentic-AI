import streamlit as st

from dotenv import load_dotenv

from langchain_google_genai import ChatGoogleGenerativeAI

from utils.rag import build_vector_store
from utils.rbac import PERMISSSIONS
from utils.realtime import get_bed_availability
from utils.security import (
    redact_pii,
    prompt_injection_detected,
    validate_output
)

from utils.prompt import SYSTEM_PROMPT
from utils.logger import audit_log

# Load environment variables from .env file
load_dotenv()

# Configure Streamlit page settings
st.set_page_config(
    page_title="Hospital AI Assistant",
    layout="wide"
)

# Initialize Gemini LLM
llm = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    temperature=0.2
)

# Cache the vector store so it is created only once
@st.cache_resource
def get_retriever():
    # Build the vector database
    vectorstore = build_vector_store()

    # Return retriever that fetches top 4 relevant documents
    return vectorstore.as_retriever(
        search_kwargs={"k": 4}
    )

# Initialize retriever
retriever = get_retriever()

# Display application title
st.title("Enterprise Hospital AI assistant")

# Allow user to select their role (used for RBAC)
role = st.sidebar.selectbox(
    "Role",
    ["Doctor", "Admin", "Support"]
)

# Initialize chat history only once per user session
if "messages" not in st.session_state:
    st.session_state.messages = []

# Display previous chat messages
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# Chat input box
question = st.chat_input(
    "Ask me anything....."
)

# Execute only when user submits a question
if question:

    # Remove Personally Identifiable Information (PII)
    question = redact_pii(question)

    # Detect prompt injection attacks before processing
    if prompt_injection_detected(question):
        st.error(
            "Promp Injection detected"
        )
        st.stop()

    # Display user message
    with st.chat_message("user"):
        st.write(question)

    # Store user message in chat history
    st.session_state.messages.append(
        {
            "role": "user",
            "content": question
        }
    )

    # Keep only the last 5 conversations for conversational context
    history = "\n".join(
        [
            m["content"]
            for m in st.session_state.messages[-5:]
        ]
    )

    # Keywords that indicate real-time hospital information is required
    realtime_keywords = [
        "bed",
        "ICU",
        "availability"
    ]

    # Default intent assumes knowledge-base search
    intent = "knowledge"

    # Detect whether user is asking for real-time information
    if any(
        word in question.lower()
        for word in realtime_keywords
    ):
        intent = "realtime"

    # Role-Based Access Control (RBAC)
    # Check whether selected role is allowed to access requested intent
    if intent not in PERMISSSIONS[role]:
        answer = "Access Denied"

    else:

        # Fetch live hospital data for real-time requests
        if intent == "realtime":
            context = str(
                get_bed_availability()
            )

        else:
            # Retrieve relevant documents from vector database
            docs = retriever.invoke(
                question
            )

            # Combine retrieved document contents into a single context
            context = "\n\n".join(
                [
                    doc.page_content
                    for doc in docs
                ]
            )

        # Construct final prompt for the LLM
        prompt = f"""
{SYSTEM_PROMPT}

Role:
{role}

History:
{history}

Context:
{context}

Question:
{question}

Answer Professionally and be precise
"""

        # Send prompt to Gemini
        response = llm.invoke(prompt)
        answer = response.content

        # Perform output validation before displaying response
        if not validate_output(answer):

            answer = {
                "Response blocked by policy"
            }

    # Record interaction for auditing/compliance
    audit_log(
        role,
        question,
        answer
    )

    # Display assistant response
    with st.chat_message(
        "assistant"
    ):
        st.write(answer)

    # Save assistant response into chat history
    st.session_state.messages.append(
        {
            "role": "assistant",
            "content": answer
        }
    )