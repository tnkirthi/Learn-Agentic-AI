import json
from datetime import datetime

def audit_log(role, question, status):
    record = {
        "timestamp": str(datetime.now()),
        "role": role,
        "question": question,
        "status": status
    }

    with open("logs/audit.log", "a") as f:
        f.write(json.dumps(record) + "\n")