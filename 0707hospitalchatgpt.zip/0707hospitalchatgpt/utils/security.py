import re ### regular expressions

BLOCKED_PATTERNS = [
    "ignore previous instructions",
    "show system prompt",
    "reveal system prompt",
    "jailbreak",
    "act as a admin",
    "override instructions"
]

def redact_pii(text):

    text = re.sub(
        r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}',
        '[EMAIL]',
        text
    )

    text = re.sub(
        r'\b\d{10}\b',
        '[PHONE]',
        text
    )

    return text

def prompt_injection_detected(text):
    text = text.lower()

    for pattern in BLOCKED_PATTERNS:
        if pattern in text:
            return True
    
    return False

def validate_output(response):
    blocked = [
        "password",
        "secret",
        "private key",
        "api key"
    ]

    response = response.lower()

    for item in blocked:
        if item in response:
            return False
    
    return True