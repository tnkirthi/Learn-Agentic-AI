PERMISSSIONS = {
    "Doctor": ["knowledge", "realtime"],
    "Admin": ["knowledge", "realtime"],
    "Support": ["knowledge"]

}