def get_bed_availability():
    return {
        "ICU": 5,
        "Emergency": 8,
        "General": 24,
        "Pediatric": 10
    }