### RAG logic to ingest files present under data folder

from dotenv import load_dotenv
import os

load_dotenv()

### invoking langchain libraries

from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_chroma import Chroma
from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter

embeddings = GoogleGenerativeAIEmbeddings(
    model="models/gemini-embedding-001",
    google_api_key=os.getenv("GOOGLE_API_KEY")
)

DB_DIR ="chroma_db"

def build_vector_store():
    if os.path.exists(DB_DIR):

        return Chroma(
            persist_directory=DB_DIR,
            embedding_function=embeddings
        )
    docs = []

    for file in os.listdir("data"):
        if file.endswith(".pdf"):
            loader = PyPDFLoader(
                os.path.join("data", file)
            )
            docs.extend(loader.load())

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200
    )

    chunks = splitter.split_documents(docs)

    return Chroma.from_documents(
        chunks,
        embeddings,
        persist_directory=DB_DIR
    )
