#### create virtual environment

python -m venv venv
source venv/bin/activate

### install packages

pip install -r requirements.txt

### run the code

python3.11 -m streamlit run app.py