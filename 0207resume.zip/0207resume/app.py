import streamlit as st
from dotenv import load_dotenv
import os
from resume_processor import load_resume, analyze_resume, store_to_vectorstore, run_self_query

st.set_page_config(page_title="Resume Analyzer", layout="wide")
st.title("AI Resume Analyzer")
st.markdown("Upload your resume and job description to get an AI-powered analysis of your suitability for the role.")

job_desc = st.text_area("Paste the Job Description here:", height=200)
uploaded_file = st.file_uploader("Upload your resume (PDF, DOCX, TXT):", type=["pdf", "docx", "txt"])

if st.button("Analyze Resume") and job_desc and uploaded_file:
    with open(uploaded_file.name, "wb") as f:
        f.write(uploaded_file.getbuffer())

    with st.spinner("Processing your resume..."):
        docs = load_resume(uploaded_file.name)
        analysis_result = analyze_resume(docs, job_desc)
        store_to_vectorstore(docs)
        st.success("Analysis complete!")

        st.write("### Analysis Result:")
        st.write(analysis_result)
        st.download_button("Download Analysis Result", analysis_result, file_name="analysis_result.txt")

st.divider()
st.subheader("Ask Questions about your Resume and Job Description")

query = st.text_input("Enter your question:")
if st.button("Search Resumes") and query:
    with st.spinner("Searching resumes..."):
        answer = run_self_query(query)
        if answer:
            if isinstance(answer, str):
                st.write(answer.strip())
            else:
                for i, doc in enumerate(answer, 1):
                    st.markdown(f"### Result {i}:")
                    st.write(doc.page_content.strip() if hasattr(doc, "page_content") else str(doc).strip())

        else:
            st.write("No relevant information found in the resumes.")
