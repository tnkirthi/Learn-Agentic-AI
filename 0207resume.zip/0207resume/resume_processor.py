### application configuration

import os
from dotenv import load_dotenv

### define libraries

from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
from langchain_community.document_loaders import PyPDFLoader, Docx2txtLoader, TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter ### chunking strategy
from langchain_core.prompts import PromptTemplate
from langchain_classic.chains import LLMChain
from langchain_core.output_parsers import StrOutputParser
from langchain_chroma import Chroma

#### load environment variables
load_dotenv()

GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY","")
os.environ["GOOGLE_API_KEY"] = GOOGLE_API_KEY

## embedding model
embedding_model = GoogleGenerativeAIEmbeddings(model="models/gemini-embedding-001")

### LLM model
llm = ChatGoogleGenerativeAI(model="gemini-2.5-flash", temperature=0.3)

### loaders for different file types

def load_resume(file_path):
    if file_path.endswith('.pdf'):
        loader = PyPDFLoader(file_path)
    elif file_path.endswith('.docx'):
        loader = Docx2txtLoader(file_path)
    elif file_path.endswith('.txt'):
        loader = TextLoader(file_path, encoding ='utf-8')
    else:
        raise ValueError("Unsupported file format. Please provide a PDF, DOCX, or TXT file.")
    
    documents = loader.load()
    return documents


       
### analyze resume
def analyze_resume(docs, job_description):
    
    full_resume = "\n".join([doc.page_content for doc in docs])
    prompt = f"""
Compare the following resume chunk with the job description and give:
1. Skills matched
2. Education evaluation
3. Experience evaluation
4. Certifications evaluation
5. Suitability score (0-100) 
6. Strengths and weaknesses
7. Overall recommendation (Yes/No)

Please give priority to skills and experience matching, but also consider education and certifications. Be concise but thorough in your analysis and confine the oputput to the above points without adding extra commentary.
Job Description:
{job_description}

Resume:
{full_resume}
"""
    response = llm.invoke(prompt)
    return response.content.strip()

 #       analysis_chain = LLMChain(llm=llm, prompt=PromptTemplate.from_template(prompt), output_parser=StrOutputParser())
 #       analysis_result = analysis_chain.run(chunk.page_content)
 #       full_analysis += f"Chunk Analysis:\n{analysis_result}\n\n"
 #       result = llm.invoke(prompt)
 #       full_analysis += result.content + "\n\n"

  #  return full_analysis

### store to vector database

def store_to_vectorstore(docs, persist_directory="chroma_store"):

    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    chunks = text_splitter.split_documents(docs)

    texts = [chunk.page_content for chunk in chunks]
    metadatas = [{"source": f"resume_chunk_{i}"} for i in range(len(texts))]

    vectorstore = Chroma.from_texts(
        texts=texts,
        embedding=embedding_model,
        metadatas=metadatas,
        persist_directory=persist_directory,
        collection_name="resume_collection"
    )
    return vectorstore

### smart query function to retrieve relevant chunks from the vector store

def run_self_query(query, persist_directory="chroma_store"):
    vectorstore = Chroma(
        persist_directory=persist_directory,
        embedding_function=embedding_model
    )

    ## retriever logic for top chunks
    retriever = vectorstore.as_retriever(
        search_type="mmr", 
        search_kwargs={"k": 3}
    )

    docs = retriever.invoke(query)

    ## safe extraction of content from docs
    combined_docs = "\n\n".join([
        doc.page_content if hasattr(doc, "page_content") else str(doc) for 
        doc in docs
    ])

    prompt = f"""
You are a resume analysis assistant. Given the following query and the relevant resume chunks, provide a concise and informative response. Focus on the most relevant information from the resume chunks to answer the query effectively

Query: {query}

Resume Context:
{combined_docs}
"""
    response = llm.invoke(prompt)
    return response.content.strip()
