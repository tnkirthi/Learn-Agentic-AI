### fraud monitoring system using langgraph with groq

import os, re, time

### TypedDict defines the shared state that is passed between nodes
from typing import List, Dict, TypedDict, Any

import streamlit as st
import pandas as pd

from langchain_groq import ChatGroq
from langchain_chroma import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_core.documents import Document

### langgraph library

from langgraph.graph import StateGraph, END

st.set_page_config(page_title="Fraud Monitoring RAG", layout="wide")

#####LLM

os.environ["GROQ_API_KEY"] = "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"
GROQ_KEY = os.getenv("GROQ_API_KEY", "")

llm = None
if GROQ_KEY:
    llm = ChatGroq(
        model_name="llama-3.3-70b-versatile",
        groq_api_key=GROQ_KEY
    )

def ask_llm(prompt):
    if llm is None:
        return "Configure GROQ_API_key"
    return llm.invoke(prompt).content

### embedding model

@st.cache_resource

def get_embeddings():
    return HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-MiniLM-L6-v2"
    )

### define RAG

def build_vectorstore_from_dataframe(df):
    docs = []

    for _,row in df.iterrows():
        docs.append(
            Document(
                page_content=" | ".join(
                    [str(v) for v in row.values]
                )
            )
        )
    return Chroma.from_documents(
        documents=docs,
        embedding=get_embeddings()
    )

### retrieval logic

def retrieve_context(query):

    if "vectordb" not in st.session_state:
        return ""
    docs = st.session_state.vectordb.similarity_search(
        query,
        k=3,
        collection_name="fraudsource"
    )

    return "\n\n".join(
        d.page_content for d in docs
    )

#### state

class BotState(TypedDict, total=False):
    user_input: str
    transactions: List[Dict[str, Any]]
    amount: float
    risk: str
    risk_score: float
    retrieved_context: str

### extract amount from transactions

def parse_amount(text):
    m = re.search(r"\d+", str(text))
    return float(m.group()) if m else 0

### calculating risk score
def compute_fraud_score(text, amount, history):
    score = 0

    if amount > 100000:
        score +=30
    elif amount > 50000:
        score +=20
    
    if any(
        x in str(text).lower()
        for x in["crypto", "offshore", "unknown"]
    ):
        score +=30

    if len(history) == 0:
        score +=20

    if len(history) >=5:
        score +=5
    
    return min(score, 100)

### calculating risk level

def get_risk(score):

    if score >= 80:
        return "HIGH"
    elif score >=50:
        return "MEDIUM"
    return "LOW"

#### NODES....NODE_RAG, NODE_PROCESS. NODE_HITL

def node_rag(state):
    state["reterieved_context"] = retrieve_context(
        state["user_input"]
    )

def node_process(state):

    text = state["user_inout"]
    history = state.get("transactions", [])

    amount = parse_amount(text)

    score = compute_fraud_score(
        text,
        amount,
        history
    )

    state["amount"] = amount
    state["fraud_score"] = score
    state["risk"] = get_risk(score)

    return state

def node_hitl(state):
    state["alert"] = "Escalate to human review"
    return state

def route(state):
    return "hitl" if state["risk"] == "HIGH" else "end"

#### initialize LangGraph

builder = StateGraph(BotState)

builder.add_node("rag", node_rag)
builder.add_node("process", node_process)
builder.add_node("hitl", node_hitl)

builder.set_entry_point("rag")

builder.add_edge("rag", "process")

builder.add_conditional_edges(
    "process",
    route,
    {
        "hitl": "hitl",
        "end": END
    }
)

graph = builder.compile()

####. session management

if "transactions" not in st.session_state:
    st.session_state.transactions = []

if "explanations" not in st.session_state:
    st.session_state.explanations = {}

if "stream_df" not in st.session_state:
    st.session_state.stream_df = None

if "current_index" not in st.session_state:
    st.session_state.current_index = 0



#### define input for user

st.sidebar.header("Live Transaction Feed")

source_type = st.sidebar.radio(
    "Source Type",
    ["CSV", "WEB"]
)

if source_type == "CSV":
    file = st.sidebar.file_uploader(
        "Upload Transaction CSV",
        type=["csv"]
    )

    if file is not None:

        df = pd.read_csv(file)

        st.session_state.stream_df = df
        st.session_state.vectordb = (
            build_vectorstore_from_dataframe(df)
        )

        st.sidebar.success(
            f"{len(df)} rows loaded"
        )

else:
    url = st.sidebar.text_input(
        "Website URL"
    )

    if st.sidebar.button("Load Website") and url:
        tables = pd.read_html(url)

        df = tables[0]


        st.session_state.stream_df = df
        st.session_state.vectordb = (
            build_vectorstore_from_dataframe(df)
        )

        st.sidebar.success(
            f"{len(df)} rows loaded"
        )



############# Dashboard logic #############

st.title("Real Time Payment Fraud Monitoring System")

txns = st.session_state.transactions

col1, col2, col3 = st.columns(3)

### logic to add metrics to these columns

col1.metric(
    "Total Amount",
    f"{int(sum(t['amount'] for t in txns)):}"
    if txns else "0"
)

col2.metric(
    "High Risk",
    sum(1 for t in txns if t["risk"] == "HIGH")
)

col3.metric(
    "Medium Risk",
    sum( 1 for t in txns if t["risk"] == "MEDIUM")
)

c1, c2, c3 = st.columns(3)

start = c1.button("Process Next Transaction")
auto = c2.button("Process All")
reset = c3.button("reset")

if reset:
    st.session_state.transactions = []
    st.session_state.explanations = {}
    st.session_state.current_index = 0
    st.rerun()

##### streaming data

def process_row(row):
    msg = str(
        row["description"]
    ) if "description" in row else " | ".join(
        str(v) for v in row.values
    )

    state = graph.invoke(
        {
            "user_input": msg,
            "transactions":
            st.session_state.transactions

        }
    )

    txn = {
        "id": len(st.session_state.transactions),
        "text": msg,
        "amount": state["amount"],
        "score": state["fraud_score"],
        "risk": state["risk"],
        "context": state.get(
            "retrieved_context",
            ""
        )
    }

    st.session_state.transactions.append(txn)



if (
    start and
    st.session_state.stream_df is not None and
    st.session_state.current_index < len(st.session_state.stream_df)
):
    row = st.session_state.stream_df.iloc[
        st.session_state.current_index
    ]

    process_row(row)

    st.session_state.current_index += 1

    st.rerun()



### auto

if auto and st.session_state.stream_df is not None:

    while(
        st.session_state.current_index < len(st.session_state.stream_df)
):
        row = st.session_state.stream_df.iloc[
            st.session_state.current_index
        ]

        process_row(row)

        st.session_state.current_index += 1

### alerts

st.subheader("Active Alerts")

for a in [
    x for x in txns
    if x["risk"] == "HIGH"
][-4:]:
    st.error(
        f"{a['text']} | Score={a['score']}"
    )



##### Final UI


st.subheader("Live Transactions")

for txn in reversed(txns):

    icon = {
        "HIGH": "🔴",
        "MEDIUM": "🟡",
        "LOW": "🟢"
    }[txn["risk"]]

    c1,c2,c3,c4 = st.columns([5,1,1,1])

    c1.write(f"{icon} {txn['text']}")
    c2.write(int(txn["amount"]))
    c3.write(txn["score"])

    explain = c4.button(
        "Explain",
        key=f"exp_{txn['id']}"
    )

    if explain:

        prompt = f"""
Transactions:
{txn['text']}

Risk:
{txn['risk']}

Fraud Score:
{txn['score']}

Similar Transactions:
{txn['context']}

Explain risk, fraud indicators and recommendations. Please keep the answer precise to maximum 3-4 lines
"""
        st.session_state.explanations[
            txn["id"]
        ] = ask_llm(prompt)
    
    if txn["id"] in st.session_state.explanations:
        st.info(
            st.session_state.explanations[
                txn["id"]
            ]
        )



             


